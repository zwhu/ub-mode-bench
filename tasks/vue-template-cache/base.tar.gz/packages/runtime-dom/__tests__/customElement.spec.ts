import type { MockedFunction } from 'vitest'
import {
  type HMRRuntime,
  type Ref,
  Teleport,
  type VueElement,
  createApp,
  defineAsyncComponent,
  defineComponent,
  defineCustomElement,
  h,
  inject,
  nextTick,
  onMounted,
  provide,
  ref,
  render,
  renderSlot,
  useHost,
  useShadowRoot,
} from '../src'

declare var __VUE_HMR_RUNTIME__: HMRRuntime

describe('defineCustomElement', () => {
  const container = document.createElement('div')
  document.body.appendChild(container)

  beforeEach(() => {
    container.innerHTML = ''
  })

  describe('mounting/unmount', () => {
    const E = defineCustomElement({
      props: {
        msg: {
          type: String,
          default: 'hello',
        },
      },
      render() {
        return h('div', this.msg)
      },
    })
    customElements.define('my-element', E)

    test('should work', () => {
      container.innerHTML = `<my-element></my-element>`
      const e = container.childNodes[0] as VueElement
      expect(e).toBeInstanceOf(E)
      expect(e._instance).toBeTruthy()
      expect(e.shadowRoot!.innerHTML).toBe(`<div>hello</div>`)
    })

    test('should work w/ manual instantiation', () => {
      const e = new E({ msg: 'inline' })
      // should lazy init
      expect(e._instance).toBe(null)
      // should initialize on connect
      container.appendChild(e)
      expect(e._instance).toBeTruthy()
      expect(e.shadowRoot!.innerHTML).toBe(`<div>inline</div>`)
    })

    test('should unmount on remove', async () => {
      container.innerHTML = `<my-element></my-element>`
      const e = container.childNodes[0] as VueElement
      container.removeChild(e)
      await nextTick()
      expect(e._instance).toBe(null)
      expect(e.shadowRoot!.innerHTML).toBe('')
    })

    // #10610
    test('When elements move, avoid prematurely disconnecting MutationObserver', async () => {
      const CustomInput = defineCustomElement({
        props: ['value'],
        emits: ['update'],
        setup(props, { emit }) {
          return () =>
            h('input', {
              type: 'number',
              value: props.value,
              onInput: (e: InputEvent) => {
                const num = (e.target! as HTMLInputElement).valueAsNumber
                emit('update', Number.isNaN(num) ? null : num)
              },
            })
        },
      })
      customElements.define('my-el-input', CustomInput)
      const num = ref('12')
      const containerComp = defineComponent({
        setup() {
          return () => {
            return h('div', [
              h('my-el-input', {
                value: num.value,
                onUpdate: ($event: CustomEvent) => {
                  num.value = $event.detail[0]
                },
              }),
              h('div', { id: 'move' }),
            ])
          }
        },
      })
      const app = createApp(containerComp)
      const container = document.createElement('div')
      document.body.appendChild(container)
      app.mount(container)
      const myInputEl = container.querySelector('my-el-input')!
      const inputEl = myInputEl.shadowRoot!.querySelector('input')!
      await nextTick()
      expect(inputEl.value).toBe('12')
      const moveEl = container.querySelector('#move')!
      moveEl.append(myInputEl)
      await nextTick()
      myInputEl.removeAttribute('value')
      await nextTick()
      expect(inputEl.value).toBe('')
    })

    test('should not unmount on move', async () => {
      container.innerHTML = `<div><my-element></my-element></div>`
      const e = container.childNodes[0].childNodes[0] as VueElement
      const i = e._instance
      // moving from one parent to another - this will trigger both disconnect
      // and connected callbacks synchronously
      container.appendChild(e)
      await nextTick()
      // should be the same instance
      expect(e._instance).toBe(i)
      expect(e.shadowRoot!.innerHTML).toBe('<div>hello</div>')
    })

    test('remove then insert again', async () => {
      container.innerHTML = `<my-element></my-element>`
      const e = container.childNodes[0] as VueElement
      container.removeChild(e)
      await nextTick()
      expect(e._instance).toBe(null)
      expect(e.shadowRoot!.innerHTML).toBe('')
      container.appendChild(e)
      expect(e._instance).toBeTruthy()
      expect(e.shadowRoot!.innerHTML).toBe('<div>hello</div>')
    })
  })

  describe('props', () => {
    const E = defineCustomElement({
      props: {
        foo: [String, null],
        bar: Object,
        bazQux: null,
        value: null,
      },
      render() {
        return [
          h('div', null, this.foo || ''),
          h('div', null, this.bazQux || (this.bar && this.bar.x)),
        ]
      },
    })
    customElements.define('my-el-props', E)

    test('renders custom element w/ correct object prop value', () => {
      render(h('my-el-props', { value: { x: 1 } }), container)
      const el = container.children[0]
      expect((el as any).value).toEqual({ x: 1 })
    })

    test('props via attribute', async () => {
      // bazQux should map to `baz-qux` attribute
      container.innerHTML = `<my-el-props foo="hello" baz-qux="bye"></my-el-props>`
      const e = container.childNodes[0] as VueElement
      expect(e.shadowRoot!.innerHTML).toBe('<div>hello</div><div>bye</div>')

      // change attr
      e.setAttribute('foo', 'changed')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div>changed</div><div>bye</div>')

      e.setAttribute('baz-qux', 'changed')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        '<div>changed</div><div>changed</div>',
      )
    })

    test('props via properties', async () => {
      const e = new E()
      e.foo = 'one'
      e.bar = { x: 'two' }
      container.appendChild(e)
      expect(e.shadowRoot!.innerHTML).toBe('<div>one</div><div>two</div>')

      // reflect
      // should reflect primitive value
      expect(e.getAttribute('foo')).toBe('one')
      // should not reflect rich data
      expect(e.hasAttribute('bar')).toBe(false)

      e.foo = 'three'
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div>three</div><div>two</div>')
      expect(e.getAttribute('foo')).toBe('three')

      e.foo = null
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div></div><div>two</div>')
      expect(e.hasAttribute('foo')).toBe(false)

      e.foo = undefined
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div></div><div>two</div>')
      expect(e.hasAttribute('foo')).toBe(false)
      expect(e.foo).toBe(undefined)

      e.bazQux = 'four'
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div></div><div>four</div>')
      expect(e.getAttribute('baz-qux')).toBe('four')
    })

    test('props via attributes and properties changed together', async () => {
      const e = new E()
      e.foo = 'foo1'
      e.bar = { x: 'bar1' }
      container.appendChild(e)
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div>foo1</div><div>bar1</div>')

      // change attr then property
      e.setAttribute('foo', 'foo2')
      e.bar = { x: 'bar2' }
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div>foo2</div><div>bar2</div>')
      expect(e.getAttribute('foo')).toBe('foo2')
      expect(e.hasAttribute('bar')).toBe(false)

      // change prop then attr
      e.bar = { x: 'bar3' }
      e.setAttribute('foo', 'foo3')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div>foo3</div><div>bar3</div>')
      expect(e.getAttribute('foo')).toBe('foo3')
      expect(e.hasAttribute('bar')).toBe(false)
    })

    test('props via hyphen property', async () => {
      const Comp = defineCustomElement({
        props: {
          fooBar: Boolean,
        },
        render() {
          return 'Comp'
        },
      })
      customElements.define('my-el-comp', Comp)
      render(h('my-el-comp', { 'foo-bar': true }), container)
      const el = container.children[0]
      expect((el as any).outerHTML).toBe('<my-el-comp foo-bar=""></my-el-comp>')
    })

    test('attribute -> prop type casting', async () => {
      const E = defineCustomElement({
        props: {
          fooBar: Number, // test casting of camelCase prop names
          bar: Boolean,
          baz: String,
        },
        render() {
          return [
            this.fooBar,
            typeof this.fooBar,
            this.bar,
            typeof this.bar,
            this.baz,
            typeof this.baz,
          ].join(' ')
        },
      })
      customElements.define('my-el-props-cast', E)
      container.innerHTML = `<my-el-props-cast foo-bar="1" baz="12345"></my-el-props-cast>`
      const e = container.childNodes[0] as VueElement
      expect(e.shadowRoot!.innerHTML).toBe(
        `1 number false boolean 12345 string`,
      )

      e.setAttribute('bar', '')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(`1 number true boolean 12345 string`)

      e.setAttribute('foo-bar', '2e1')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `20 number true boolean 12345 string`,
      )

      e.setAttribute('baz', '2e1')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(`20 number true boolean 2e1 string`)
    })

    // #4772
    test('attr casting w/ programmatic creation', () => {
      const E = defineCustomElement({
        props: {
          foo: Number,
        },
        render() {
          return `foo type: ${typeof this.foo}`
        },
      })
      customElements.define('my-element-programmatic', E)
      const el = document.createElement('my-element-programmatic') as any
      el.setAttribute('foo', '123')
      container.appendChild(el)
      expect(el.shadowRoot.innerHTML).toBe(`foo type: number`)
    })

    test('handling properties set before upgrading', () => {
      const E = defineCustomElement({
        props: {
          foo: String,
          dataAge: Number,
        },
        setup(props) {
          expect(props.foo).toBe('hello')
          expect(props.dataAge).toBe(5)
        },
        render() {
          return h('div', `foo: ${this.foo}`)
        },
      })
      const el = document.createElement('my-el-upgrade') as any
      el.foo = 'hello'
      el.dataset.age = 5
      el.notProp = 1
      container.appendChild(el)
      customElements.define('my-el-upgrade', E)
      expect(el.shadowRoot.firstChild.innerHTML).toBe(`foo: hello`)
      // should not reflect if not declared as a prop
      expect(el.hasAttribute('not-prop')).toBe(false)
    })

    test('handle properties set before connecting', () => {
      const obj = { a: 1 }
      const E = defineCustomElement({
        props: {
          foo: String,
          post: Object,
        },
        setup(props) {
          expect(props.foo).toBe('hello')
          expect(props.post).toBe(obj)
        },
        render() {
          return JSON.stringify(this.post)
        },
      })
      customElements.define('my-el-preconnect', E)
      const el = document.createElement('my-el-preconnect') as any
      el.foo = 'hello'
      el.post = obj

      container.appendChild(el)
      expect(el.shadowRoot.innerHTML).toBe(JSON.stringify(obj))
    })

    // https://github.com/vuejs/core/issues/6163
    test('handle components with no props', async () => {
      const E = defineCustomElement({
        render() {
          return h('div', 'foo')
        },
      })
      customElements.define('my-element-noprops', E)
      const el = document.createElement('my-element-noprops')
      container.appendChild(el)
      await nextTick()
      expect(el.shadowRoot!.innerHTML).toMatchInlineSnapshot('"<div>foo</div>"')
    })

    // #5793
    test('set number value in dom property', () => {
      const E = defineCustomElement({
        props: {
          'max-age': Number,
        },
        render() {
          // @ts-expect-error
          return `max age: ${this.maxAge}/type: ${typeof this.maxAge}`
        },
      })
      customElements.define('my-element-number-property', E)
      const el = document.createElement('my-element-number-property') as any
      container.appendChild(el)
      el.maxAge = 50
      expect(el.maxAge).toBe(50)
      expect(el.shadowRoot.innerHTML).toBe('max age: 50/type: number')
    })

    // #9006
    test('should reflect default value', () => {
      const E = defineCustomElement({
        props: {
          value: {
            type: String,
            default: 'hi',
          },
        },
        render() {
          return this.value
        },
      })
      customElements.define('my-el-default-val', E)
      container.innerHTML = `<my-el-default-val></my-el-default-val>`
      const e = container.childNodes[0] as any
      expect(e.value).toBe('hi')
    })

    // #12214
    test('Boolean prop with default true', async () => {
      const E = defineCustomElement({
        props: {
          foo: {
            type: Boolean,
            default: true,
          },
        },
        render() {
          return String(this.foo)
        },
      })
      customElements.define('my-el-default-true', E)
      container.innerHTML = `<my-el-default-true></my-el-default-true>`
      const e = container.childNodes[0] as HTMLElement & { foo: any },
        shadowRoot = e.shadowRoot as ShadowRoot
      expect(shadowRoot.innerHTML).toBe('true')
      e.foo = undefined
      await nextTick()
      expect(shadowRoot.innerHTML).toBe('true')
      e.foo = false
      await nextTick()
      expect(shadowRoot.innerHTML).toBe('false')
      e.foo = null
      await nextTick()
      expect(shadowRoot.innerHTML).toBe('null')
      e.foo = ''
      await nextTick()
      expect(shadowRoot.innerHTML).toBe('true')
    })

    test('support direct setup function syntax with extra options', () => {
      const E = defineCustomElement(
        props => {
          return () => props.text
        },
        {
          props: {
            text: String,
          },
        },
      )
      customElements.define('my-el-setup-with-props', E)
      container.innerHTML = `<my-el-setup-with-props text="hello"></my-el-setup-with-props>`
      const e = container.childNodes[0] as VueElement
      expect(e.shadowRoot!.innerHTML).toBe('hello')
    })

    test('prop types validation', async () => {
      const E = defineCustomElement({
        props: {
          num: {
            type: [Number, String],
          },
          bool: {
            type: Boolean,
          },
        },
        render() {
          return h('div', [
            h('span', [`${this.num} is ${typeof this.num}`]),
            h('span', [`${this.bool} is ${typeof this.bool}`]),
          ])
        },
      })

      customElements.define('my-el-with-type-props', E)
      render(h('my-el-with-type-props', { num: 1, bool: true }), container)
      const e = container.childNodes[0] as VueElement
      // @ts-expect-error
      expect(e.num).toBe(1)
      // @ts-expect-error
      expect(e.bool).toBe(true)
      expect(e.shadowRoot!.innerHTML).toBe(
        '<div><span>1 is number</span><span>true is boolean</span></div>',
      )
    })

    test('should patch all props together', async () => {
      let prop1Calls = 0
      let prop2Calls = 0
      const E = defineCustomElement({
        props: {
          prop1: {
            type: String,
            default: 'default1',
          },
          prop2: {
            type: String,
            default: 'default2',
          },
        },
        data() {
          return {
            data1: 'defaultData1',
            data2: 'defaultData2',
          }
        },
        watch: {
          prop1(_) {
            prop1Calls++
            this.data2 = this.prop2
          },
          prop2(_) {
            prop2Calls++
            this.data1 = this.prop1
          },
        },
        render() {
          return h('div', [
            h('h1', this.prop1),
            h('h1', this.prop2),
            h('h2', this.data1),
            h('h2', this.data2),
          ])
        },
      })
      customElements.define('my-watch-element', E)

      render(h('my-watch-element'), container)
      const e = container.childNodes[0] as VueElement
      expect(e).toBeInstanceOf(E)
      expect(e._instance).toBeTruthy()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>default1</h1><h1>default2</h1><h2>defaultData1</h2><h2>defaultData2</h2></div>`,
      )
      expect(prop1Calls).toBe(0)
      expect(prop2Calls).toBe(0)

      // patch props
      render(
        h('my-watch-element', { prop1: 'newValue1', prop2: 'newValue2' }),
        container,
      )
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>newValue1</h1><h1>newValue2</h1><h2>newValue1</h2><h2>newValue2</h2></div>`,
      )
      expect(prop1Calls).toBe(1)
      expect(prop2Calls).toBe(1)

      // same prop values
      render(
        h('my-watch-element', { prop1: 'newValue1', prop2: 'newValue2' }),
        container,
      )
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>newValue1</h1><h1>newValue2</h1><h2>newValue1</h2><h2>newValue2</h2></div>`,
      )
      expect(prop1Calls).toBe(1)
      expect(prop2Calls).toBe(1)

      // update only prop1
      render(
        h('my-watch-element', { prop1: 'newValue3', prop2: 'newValue2' }),
        container,
      )
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>newValue3</h1><h1>newValue2</h1><h2>newValue1</h2><h2>newValue2</h2></div>`,
      )
      expect(prop1Calls).toBe(2)
      expect(prop2Calls).toBe(1)
    })

    test('should patch all props together (async)', async () => {
      let prop1Calls = 0
      let prop2Calls = 0
      const E = defineCustomElement(
        defineAsyncComponent(() =>
          Promise.resolve(
            defineComponent({
              props: {
                prop1: {
                  type: String,
                  default: 'default1',
                },
                prop2: {
                  type: String,
                  default: 'default2',
                },
              },
              data() {
                return {
                  data1: 'defaultData1',
                  data2: 'defaultData2',
                }
              },
              watch: {
                prop1(_) {
                  prop1Calls++
                  this.data2 = this.prop2
                },
                prop2(_) {
                  prop2Calls++
                  this.data1 = this.prop1
                },
              },
              render() {
                return h('div', [
                  h('h1', this.prop1),
                  h('h1', this.prop2),
                  h('h2', this.data1),
                  h('h2', this.data2),
                ])
              },
            }),
          ),
        ),
      )
      customElements.define('my-async-watch-element', E)

      render(h('my-async-watch-element'), container)

      await new Promise(r => setTimeout(r))
      const e = container.childNodes[0] as VueElement
      expect(e).toBeInstanceOf(E)
      expect(e._instance).toBeTruthy()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>default1</h1><h1>default2</h1><h2>defaultData1</h2><h2>defaultData2</h2></div>`,
      )
      expect(prop1Calls).toBe(0)
      expect(prop2Calls).toBe(0)

      // patch props
      render(
        h('my-async-watch-element', { prop1: 'newValue1', prop2: 'newValue2' }),
        container,
      )
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>newValue1</h1><h1>newValue2</h1><h2>newValue1</h2><h2>newValue2</h2></div>`,
      )
      expect(prop1Calls).toBe(1)
      expect(prop2Calls).toBe(1)

      // same prop values
      render(
        h('my-async-watch-element', { prop1: 'newValue1', prop2: 'newValue2' }),
        container,
      )
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>newValue1</h1><h1>newValue2</h1><h2>newValue1</h2><h2>newValue2</h2></div>`,
      )
      expect(prop1Calls).toBe(1)
      expect(prop2Calls).toBe(1)

      // update only prop1
      render(
        h('my-async-watch-element', { prop1: 'newValue3', prop2: 'newValue2' }),
        container,
      )
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><h1>newValue3</h1><h1>newValue2</h1><h2>newValue1</h2><h2>newValue2</h2></div>`,
      )
      expect(prop1Calls).toBe(2)
      expect(prop2Calls).toBe(1)
    })
  })

  describe('attrs', () => {
    const E = defineCustomElement({
      render() {
        return [h('div', null, this.$attrs.foo as string)]
      },
    })
    customElements.define('my-el-attrs', E)

    test('attrs via attribute', async () => {
      container.innerHTML = `<my-el-attrs foo="hello"></my-el-attrs>`
      const e = container.childNodes[0] as VueElement
      expect(e.shadowRoot!.innerHTML).toBe('<div>hello</div>')

      e.setAttribute('foo', 'changed')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe('<div>changed</div>')
    })

    test('non-declared properties should not show up in $attrs', () => {
      const e = new E()
      // @ts-expect-error
      e.foo = '123'
      container.appendChild(e)
      expect(e.shadowRoot!.innerHTML).toBe('<div></div>')
    })

    // #12408
    test('should set number tabindex as attribute', () => {
      render(h('my-el-attrs', { tabindex: 1, 'data-test': true }), container)
      const el = container.children[0] as HTMLElement
      expect(el.getAttribute('tabindex')).toBe('1')
      expect(el.getAttribute('data-test')).toBe('true')
    })

    test('should keep undeclared native attrs as attrs', () => {
      const root = document.createElement('div')
      document.body.appendChild(root)

      render(h('my-el-attrs', { translate: 'no' }), root)
      const el = root.children[0] as HTMLElement
      expect(el.getAttribute('translate')).toBe('no')
      expect(el.translate).toBe(false)

      render(null, root)
      root.remove()
    })

    // https://github.com/vuejs/core/issues/12964
    // Disabled because of missing support for `delegatesFocus` in jsdom
    // https://github.com/jsdom/jsdom/issues/3418
    // eslint-disable-next-line vitest/no-disabled-tests
    test.skip('shadowRoot should be initialized with delegatesFocus', () => {
      const E = defineCustomElement(
        {
          render() {
            return [h('input', { tabindex: 1 })]
          },
        },
        { shadowRootOptions: { delegatesFocus: true } },
      )
      customElements.define('my-el-with-delegate-focus', E)

      const e = new E()
      container.appendChild(e)
      expect(e.shadowRoot!.delegatesFocus).toBe(true)
    })
  })

  describe('emits', () => {
    const CompDef = defineComponent({
      setup(_, { emit }) {
        emit('created')
        return () =>
          h('div', {
            onClick: () => {
              emit('my-click', 1)
            },
            onMousedown: () => {
              emit('myEvent', 1) // validate hyphenation
            },
            onWheel: () => {
              emit('my-wheel', { bubbles: true }, 1)
            },
          })
      },
    })
    const E = defineCustomElement(CompDef)
    customElements.define('my-el-emits', E)

    test('emit on connect', () => {
      const e = new E()
      const spy = vi.fn()
      e.addEventListener('created', spy)
      container.appendChild(e)
      expect(spy).toHaveBeenCalled()
    })

    test('emit on interaction', () => {
      container.innerHTML = `<my-el-emits></my-el-emits>`
      const e = container.childNodes[0] as VueElement
      const spy = vi.fn()
      e.addEventListener('my-click', spy)
      e.shadowRoot!.childNodes[0].dispatchEvent(new CustomEvent('click'))
      expect(spy).toHaveBeenCalledTimes(1)
      expect(spy.mock.calls[0][0]).toMatchObject({
        detail: [1],
      })
    })

    // #5373
    test('case transform for camelCase event', () => {
      container.innerHTML = `<my-el-emits></my-el-emits>`
      const e = container.childNodes[0] as VueElement
      const spy1 = vi.fn()
      e.addEventListener('myEvent', spy1)
      const spy2 = vi.fn()
      // emitting myEvent, but listening for my-event. This happens when
      // using the custom element in a Vue template
      e.addEventListener('my-event', spy2)
      e.shadowRoot!.childNodes[0].dispatchEvent(new CustomEvent('mousedown'))
      expect(spy1).toHaveBeenCalledTimes(1)
      expect(spy2).toHaveBeenCalledTimes(1)
    })

    test('emit from within async component wrapper', async () => {
      const p = new Promise<typeof CompDef>(res => res(CompDef as any))
      const E = defineCustomElement(defineAsyncComponent(() => p))
      customElements.define('my-async-el-emits', E)
      container.innerHTML = `<my-async-el-emits></my-async-el-emits>`
      const e = container.childNodes[0] as VueElement
      const spy = vi.fn()
      e.addEventListener('my-click', spy)
      // this feels brittle but seems necessary to reach the node in the DOM.
      await customElements.whenDefined('my-async-el-emits')
      await nextTick()
      await nextTick()
      e.shadowRoot!.childNodes[0].dispatchEvent(new CustomEvent('click'))
      expect(spy).toHaveBeenCalled()
      expect(spy.mock.calls[0][0]).toMatchObject({
        detail: [1],
      })
    })

    // #7293
    test('emit in an async component wrapper with properties bound', async () => {
      const E = defineCustomElement(
        defineAsyncComponent(
          () => new Promise<typeof CompDef>(res => res(CompDef as any)),
        ),
      )
      customElements.define('my-async-el-props-emits', E)
      container.innerHTML = `<my-async-el-props-emits id="my_async_el_props_emits"></my-async-el-props-emits>`
      const e = container.childNodes[0] as VueElement
      const spy = vi.fn()
      e.addEventListener('my-click', spy)
      await customElements.whenDefined('my-async-el-props-emits')
      await nextTick()
      await nextTick()
      e.shadowRoot!.childNodes[0].dispatchEvent(new CustomEvent('click'))
      expect(spy).toHaveBeenCalled()
      expect(spy.mock.calls[0][0]).toMatchObject({
        detail: [1],
      })
    })

    test('emit with options', async () => {
      container.innerHTML = `<my-el-emits></my-el-emits>`
      const e = container.childNodes[0] as VueElement
      const spy = vi.fn()
      e.addEventListener('my-wheel', spy)
      e.shadowRoot!.childNodes[0].dispatchEvent(new CustomEvent('wheel'))
      expect(spy).toHaveBeenCalledTimes(1)
      expect(spy.mock.calls[0][0]).toMatchObject({
        bubbles: true,
        detail: [{ bubbles: true }, 1],
      })
    })
  })

  describe('slots', () => {
    const E = defineCustomElement({
      render() {
        return [
          h('div', null, [
            renderSlot(this.$slots, 'default', undefined, () => [
              h('div', 'fallback'),
            ]),
          ]),
          h('div', null, renderSlot(this.$slots, 'named')),
        ]
      },
    })
    customElements.define('my-el-slots', E)

    test('render slots correctly', () => {
      container.innerHTML = `<my-el-slots><span>hi</span></my-el-slots>`
      const e = container.childNodes[0] as VueElement
      // native slots allocation does not affect innerHTML, so we just
      // verify that we've rendered the correct native slots here...
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><slot><div>fallback</div></slot></div><div><slot name="named"></slot></div>`,
      )
    })

    test('render slot props', async () => {
      const foo = ref('foo')
      const E = defineCustomElement({
        render() {
          return [
            h(
              'div',
              null,
              renderSlot(this.$slots, 'default', { class: foo.value }),
            ),
          ]
        },
      })
      customElements.define('my-el-slot-props', E)
      container.innerHTML = `<my-el-slot-props><span>hi</span></my-el-slot-props>`
      const e = container.childNodes[0] as VueElement
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><slot class="foo"></slot></div>`,
      )

      foo.value = 'bar'
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><slot class="bar"></slot></div>`,
      )
    })
  })

  describe('provide/inject', () => {
    const Consumer = defineCustomElement({
      setup() {
        const foo = inject<Ref>('foo')!
        return () => h('div', foo.value)
      },
    })
    customElements.define('my-consumer', Consumer)

    test('over nested usage', async () => {
      const foo = ref('injected!')
      const Provider = defineCustomElement({
        provide: {
          foo,
        },
        render() {
          return h('my-consumer')
        },
      })
      customElements.define('my-provider', Provider)
      container.innerHTML = `<my-provider><my-provider>`
      const provider = container.childNodes[0] as VueElement
      const consumer = provider.shadowRoot!.childNodes[0] as VueElement

      expect(consumer.shadowRoot!.innerHTML).toBe(`<div>injected!</div>`)

      foo.value = 'changed!'
      await nextTick()
      expect(consumer.shadowRoot!.innerHTML).toBe(`<div>changed!</div>`)
    })

    test('over slot composition', async () => {
      const foo = ref('injected!')
      const Provider = defineCustomElement({
        provide: {
          foo,
        },
        render() {
          return renderSlot(this.$slots, 'default')
        },
      })
      customElements.define('my-provider-2', Provider)

      container.innerHTML = `<my-provider-2><my-consumer></my-consumer><my-provider-2>`
      const provider = container.childNodes[0]
      const consumer = provider.childNodes[0] as VueElement
      expect(consumer.shadowRoot!.innerHTML).toBe(`<div>injected!</div>`)

      foo.value = 'changed!'
      await nextTick()
      expect(consumer.shadowRoot!.innerHTML).toBe(`<div>changed!</div>`)
    })

    test('inherited from ancestors', async () => {
      const fooA = ref('FooA!')
      const fooB = ref('FooB!')
      const ProviderA = defineCustomElement({
        provide: {
          fooA,
        },
        render() {
          return h('provider-b')
        },
      })
      const ProviderB = defineCustomElement({
        provide: {
          fooB,
        },
        render() {
          return h('my-multi-consumer')
        },
      })

      const Consumer = defineCustomElement({
        setup() {
          const fooA = inject<Ref>('fooA')!
          const fooB = inject<Ref>('fooB')!
          return () => h('div', `${fooA.value} ${fooB.value}`)
        },
      })

      customElements.define('provider-a', ProviderA)
      customElements.define('provider-b', ProviderB)
      customElements.define('my-multi-consumer', Consumer)
      container.innerHTML = `<provider-a><provider-a>`
      const providerA = container.childNodes[0] as VueElement
      const providerB = providerA.shadowRoot!.childNodes[0] as VueElement
      const consumer = providerB.shadowRoot!.childNodes[0] as VueElement

      expect(consumer.shadowRoot!.innerHTML).toBe(`<div>FooA! FooB!</div>`)

      fooA.value = 'changedA!'
      fooB.value = 'changedB!'
      await nextTick()
      expect(consumer.shadowRoot!.innerHTML).toBe(
        `<div>changedA! changedB!</div>`,
      )
    })

    test('should resolve correct parent when element is slotted in shadow DOM', async () => {
      const GrandParent = defineCustomElement({
        provide: {
          foo: ref('GrandParent'),
        },
        render() {
          return h('my-parent-in-shadow', h('slot'))
        },
      })
      const Parent = defineCustomElement({
        provide: {
          foo: ref('Parent'),
        },
        render() {
          return h('slot')
        },
      })
      customElements.define('my-grand-parent', GrandParent)
      customElements.define('my-parent-in-shadow', Parent)
      container.innerHTML = `<my-grand-parent><my-consumer></my-consumer></my-grand-parent>`
      const grandParent = container.childNodes[0] as VueElement,
        consumer = grandParent.firstElementChild as VueElement
      expect(consumer.shadowRoot!.textContent).toBe('Parent')
    })

    // #13212
    test('inherited from app context within nested elements', async () => {
      const outerValues: (string | undefined)[] = []
      const innerValues: (string | undefined)[] = []
      const innerChildValues: (string | undefined)[] = []

      const Outer = defineCustomElement(
        {
          setup() {
            outerValues.push(
              inject<string>('shared'),
              inject<string>('outer'),
              inject<string>('inner'),
            )
          },
          render() {
            return h('div', [renderSlot(this.$slots, 'default')])
          },
        },
        {
          configureApp(app) {
            app.provide('shared', 'shared')
            app.provide('outer', 'outer')
          },
        },
      )

      const Inner = defineCustomElement(
        {
          setup() {
            // ensure values are not self-injected
            provide('inner', 'inner-child')

            innerValues.push(
              inject<string>('shared'),
              inject<string>('outer'),
              inject<string>('inner'),
            )
          },
          render() {
            return h('div', [renderSlot(this.$slots, 'default')])
          },
        },
        {
          configureApp(app) {
            app.provide('outer', 'override-outer')
            app.provide('inner', 'inner')
          },
        },
      )

      const InnerChild = defineCustomElement({
        setup() {
          innerChildValues.push(
            inject<string>('shared'),
            inject<string>('outer'),
            inject<string>('inner'),
          )
        },
        render() {
          return h('div')
        },
      })

      customElements.define('provide-from-app-outer', Outer)
      customElements.define('provide-from-app-inner', Inner)
      customElements.define('provide-from-app-inner-child', InnerChild)

      container.innerHTML =
        '<provide-from-app-outer>' +
        '<provide-from-app-inner>' +
        '<provide-from-app-inner-child></provide-from-app-inner-child>' +
        '</provide-from-app-inner>' +
        '</provide-from-app-outer>'

      const outer = container.childNodes[0] as VueElement
      expect(outer.shadowRoot!.innerHTML).toBe('<div><slot></slot></div>')

      expect('[Vue warn]: injection "inner" not found.').toHaveBeenWarnedTimes(
        1,
      )
      expect(
        '[Vue warn]: App already provides property with key "outer" inherited from its parent element. ' +
          'It will be overwritten with the new value.',
      ).toHaveBeenWarnedTimes(1)

      expect(outerValues).toEqual(['shared', 'outer', undefined])
      expect(innerValues).toEqual(['shared', 'override-outer', 'inner'])
      expect(innerChildValues).toEqual([
        'shared',
        'override-outer',
        'inner-child',
      ])
    })
  })

  describe('styles', () => {
    function assertStyles(el: VueElement, css: string[]) {
      const styles = el.shadowRoot?.querySelectorAll('style')!
      expect(styles.length).toBe(css.length) // should not duplicate multiple copies from Bar
      for (let i = 0; i < css.length; i++) {
        expect(styles[i].textContent).toBe(css[i])
      }
    }

    test('should attach styles to shadow dom', async () => {
      const def = defineComponent({
        __hmrId: 'foo',
        styles: [`div { color: red; }`],
        render() {
          return h('div', 'hello')
        },
      })
      const Foo = defineCustomElement(def)
      customElements.define('my-el-with-styles', Foo)
      container.innerHTML = `<my-el-with-styles></my-el-with-styles>`
      const el = container.childNodes[0] as VueElement
      const style = el.shadowRoot?.querySelector('style')!
      expect(style.textContent).toBe(`div { color: red; }`)

      // hmr
      __VUE_HMR_RUNTIME__.reload('foo', {
        ...def,
        styles: [`div { color: blue; }`, `div { color: yellow; }`],
      } as any)

      await nextTick()
      assertStyles(el, [`div { color: blue; }`, `div { color: yellow; }`])
    })

    test("child components should inject styles to root element's shadow root", async () => {
      const Baz = () => h(Bar)
      const Bar = defineComponent({
        __hmrId: 'bar',
        styles: [`div { color: green; }`, `div { color: blue; }`],
        render() {
          return 'bar'
        },
      })
      const Foo = defineCustomElement({
        styles: [`div { color: red; }`],
        render() {
          return [h(Baz), h(Baz)]
        },
      })
      customElements.define('my-el-with-child-styles', Foo)
      container.innerHTML = `<my-el-with-child-styles></my-el-with-child-styles>`
      const el = container.childNodes[0] as VueElement

      // inject order should be child -> parent
      assertStyles(el, [
        `div { color: green; }`,
        `div { color: blue; }`,
        `div { color: red; }`,
      ])

      // hmr
      __VUE_HMR_RUNTIME__.reload(Bar.__hmrId!, {
        ...Bar,
        styles: [`div { color: red; }`, `div { color: yellow; }`],
      } as any)

      await nextTick()
      assertStyles(el, [
        `div { color: red; }`,
        `div { color: yellow; }`,
        `div { color: red; }`,
      ])

      __VUE_HMR_RUNTIME__.reload(Bar.__hmrId!, {
        ...Bar,
        styles: [`div { color: blue; }`],
      } as any)
      await nextTick()
      assertStyles(el, [`div { color: blue; }`, `div { color: red; }`])
    })

    test('root custom element HMR should preserve child-first style order', async () => {
      const Child = defineComponent({
        styles: [`div { color: green; }`],
        render() {
          return 'child'
        },
      })
      const def = defineComponent({
        __hmrId: 'root-child-style-order',
        styles: [`div { color: red; }`],
        render() {
          return h(Child)
        },
      })
      const Foo = defineCustomElement(def)
      customElements.define('my-el-root-hmr-style-order', Foo)
      container.innerHTML = `<my-el-root-hmr-style-order></my-el-root-hmr-style-order>`
      const el = container.childNodes[0] as VueElement

      assertStyles(el, [`div { color: green; }`, `div { color: red; }`])

      __VUE_HMR_RUNTIME__.reload(def.__hmrId!, {
        ...def,
        styles: [`div { color: blue; }`, `div { color: yellow; }`],
      } as any)

      await nextTick()
      assertStyles(el, [
        `div { color: green; }`,
        `div { color: blue; }`,
        `div { color: yellow; }`,
      ])
    })

    test('inject child component styles before parent styles', async () => {
      const Baz = () => h(Bar)
      const Bar = defineComponent({
        styles: [`div { color: green; }`],
        render() {
          return 'bar'
        },
      })
      const WrapperBar = defineComponent({
        styles: [`div { color: blue; }`],
        render() {
          return h(Baz)
        },
      })
      const WBaz = () => h(WrapperBar)
      const Foo = defineCustomElement({
        styles: [`div { color: red; }`],
        render() {
          return [h(Baz), h(WBaz)]
        },
      })
      customElements.define('my-el-with-wrapper-child-styles', Foo)
      container.innerHTML = `<my-el-with-wrapper-child-styles></my-el-with-wrapper-child-styles>`
      const el = container.childNodes[0] as VueElement

      // inject order should be child -> parent
      assertStyles(el, [
        `div { color: green; }`,
        `div { color: blue; }`,
        `div { color: red; }`,
      ])
    })

    test('inject nested child component styles after HMR removes parent styles', async () => {
      const Bar = defineComponent({
        __hmrId: 'nested-child-style-hmr-bar',
        styles: [`div { color: green; }`],
        render() {
          return 'bar'
        },
      })
      const WrapperBar = defineComponent({
        __hmrId: 'nested-child-style-hmr-wrapper',
        styles: [`div { color: blue; }`],
        render() {
          return h(Bar)
        },
      })
      const Foo = defineCustomElement({
        styles: [`div { color: red; }`],
        render() {
          return h(WrapperBar)
        },
      })
      customElements.define('my-el-with-hmr-nested-child-styles', Foo)
      container.innerHTML = `<my-el-with-hmr-nested-child-styles></my-el-with-hmr-nested-child-styles>`
      const el = container.childNodes[0] as VueElement

      assertStyles(el, [
        `div { color: green; }`,
        `div { color: blue; }`,
        `div { color: red; }`,
      ])

      __VUE_HMR_RUNTIME__.reload(WrapperBar.__hmrId!, {
        ...WrapperBar,
        styles: undefined,
      } as any)
      await nextTick()
      assertStyles(el, [`div { color: green; }`, `div { color: red; }`])

      __VUE_HMR_RUNTIME__.reload(Bar.__hmrId!, {
        ...Bar,
        styles: [`div { color: yellow; }`],
      } as any)
      await nextTick()
      assertStyles(el, [`div { color: yellow; }`, `div { color: red; }`])
    })

    test('inject child component styles when parent has no styles', async () => {
      const Baz = () => h(Bar)
      const Bar = defineComponent({
        styles: [`div { color: green; }`],
        render() {
          return 'bar'
        },
      })
      const WrapperBar = defineComponent({
        styles: [`div { color: blue; }`],
        render() {
          return h(Baz)
        },
      })
      const WBaz = () => h(WrapperBar)
      // without styles
      const Foo = defineCustomElement({
        render() {
          return [h(Baz), h(WBaz)]
        },
      })
      customElements.define('my-el-with-inject-child-styles', Foo)
      container.innerHTML = `<my-el-with-inject-child-styles></my-el-with-inject-child-styles>`
      const el = container.childNodes[0] as VueElement

      assertStyles(el, [`div { color: green; }`, `div { color: blue; }`])
    })

    test('inject nested child component styles', async () => {
      const Baz = defineComponent({
        styles: [`div { color: yellow; }`],
        render() {
          return h(Bar)
        },
      })
      const Bar = defineComponent({
        styles: [`div { color: green; }`],
        render() {
          return 'bar'
        },
      })
      const WrapperBar = defineComponent({
        styles: [`div { color: blue; }`],
        render() {
          return h(Baz)
        },
      })
      const WBaz = defineComponent({
        styles: [`div { color: black; }`],
        render() {
          return h(WrapperBar)
        },
      })
      const Foo = defineCustomElement({
        styles: [`div { color: red; }`],
        render() {
          return [h(Baz), h(WBaz)]
        },
      })
      customElements.define('my-el-with-inject-nested-child-styles', Foo)
      container.innerHTML = `<my-el-with-inject-nested-child-styles></my-el-with-inject-nested-child-styles>`
      const el = container.childNodes[0] as VueElement
      assertStyles(el, [
        `div { color: green; }`,
        `div { color: yellow; }`,
        `div { color: blue; }`,
        `div { color: black; }`,
        `div { color: red; }`,
      ])
    })

    test("child components should not inject styles to root element's shadow root w/ shadowRoot false", async () => {
      const Bar = defineComponent({
        styles: [`div { color: green; }`],
        render() {
          return 'bar'
        },
      })
      const Baz = () => h(Bar)
      const Foo = defineCustomElement(
        {
          render() {
            return [h(Baz)]
          },
        },
        { shadowRoot: false },
      )

      customElements.define('my-foo-with-shadowroot-false', Foo)
      container.innerHTML = `<my-foo-with-shadowroot-false></my-foo-with-shadowroot-false>`
      const el = container.childNodes[0] as VueElement
      const style = el.shadowRoot?.querySelector('style')
      expect(style).toBeUndefined()
    })

    test('with nonce', () => {
      const Foo = defineCustomElement(
        {
          styles: [`div { color: red; }`],
          render() {
            return h('div', 'hello')
          },
        },
        { nonce: 'xxx' },
      )
      customElements.define('my-el-with-nonce', Foo)
      container.innerHTML = `<my-el-with-nonce></my-el-with-nonce>`
      const el = container.childNodes[0] as VueElement
      const style = el.shadowRoot?.querySelector('style')!
      expect(style.getAttribute('nonce')).toBe('xxx')
    })
  })

  describe('async', () => {
    test('should work', async () => {
      const loaderSpy = vi.fn()
      const E = defineCustomElement(
        defineAsyncComponent(() => {
          loaderSpy()
          return Promise.resolve({
            props: ['msg'],
            styles: [`div { color: red }`],
            render(this: any) {
              return h('div', null, this.msg)
            },
          })
        }),
      )
      customElements.define('my-el-async', E)
      container.innerHTML =
        `<my-el-async msg="hello"></my-el-async>` +
        `<my-el-async msg="world"></my-el-async>`

      await new Promise(r => setTimeout(r))

      // loader should be called only once
      expect(loaderSpy).toHaveBeenCalledTimes(1)

      const e1 = container.childNodes[0] as VueElement
      const e2 = container.childNodes[1] as VueElement

      // should inject styles
      expect(e1.shadowRoot!.innerHTML).toBe(
        `<style>div { color: red }</style><div>hello</div>`,
      )
      expect(e2.shadowRoot!.innerHTML).toBe(
        `<style>div { color: red }</style><div>world</div>`,
      )

      // attr
      e1.setAttribute('msg', 'attr')
      await nextTick()
      expect((e1 as any).msg).toBe('attr')
      expect(e1.shadowRoot!.innerHTML).toBe(
        `<style>div { color: red }</style><div>attr</div>`,
      )

      // props
      expect(`msg` in e1).toBe(true)
      ;(e1 as any).msg = 'prop'
      expect(e1.getAttribute('msg')).toBe('prop')
      expect(e1.shadowRoot!.innerHTML).toBe(
        `<style>div { color: red }</style><div>prop</div>`,
      )
    })

    test('set DOM property before resolve', async () => {
      const E = defineCustomElement(
        defineAsyncComponent(() => {
          return Promise.resolve({
            props: ['msg'],
            setup(props) {
              expect(typeof props.msg).toBe('string')
            },
            render(this: any) {
              return h('div', this.msg)
            },
          })
        }),
      )
      customElements.define('my-el-async-2', E)

      const e1 = new E()

      // set property before connect
      e1.msg = 'hello'

      const e2 = new E()

      container.appendChild(e1)
      container.appendChild(e2)

      // set property after connect but before resolve
      e2.msg = 'world'

      await new Promise(r => setTimeout(r))

      expect(e1.shadowRoot!.innerHTML).toBe(`<div>hello</div>`)
      expect(e2.shadowRoot!.innerHTML).toBe(`<div>world</div>`)

      e1.msg = 'world'
      expect(e1.shadowRoot!.innerHTML).toBe(`<div>world</div>`)

      e2.msg = 'hello'
      expect(e2.shadowRoot!.innerHTML).toBe(`<div>hello</div>`)
    })

    test('render object prop before resolve', async () => {
      const AsyncComp = defineComponent({
        props: { value: Object },
        render(this: any) {
          return h('div', this.value.x)
        },
      })
      let resolve!: (comp: typeof AsyncComp) => void
      const p = new Promise<typeof AsyncComp>(res => {
        resolve = res
      })
      const E = defineCustomElement(defineAsyncComponent(() => p))
      customElements.define('my-el-async-object-prop', E)

      const root = document.createElement('div')
      document.body.appendChild(root)
      const value = { x: 1 }

      render(h('my-el-async-object-prop', { value }), root)

      const el = root.children[0] as VueElement & { value: typeof value }
      expect(el.value).toBe(value)
      expect(el.getAttribute('value')).toBe(null)

      resolve(AsyncComp)

      await new Promise(r => setTimeout(r))

      expect(el.value).toBe(value)
      expect(el.getAttribute('value')).toBe(null)
      expect(el.shadowRoot!.innerHTML).toBe(`<div>1</div>`)

      render(null, root)
      root.remove()
    })

    test('Number prop casting before resolve', async () => {
      const E = defineCustomElement(
        defineAsyncComponent(() => {
          return Promise.resolve({
            props: { n: Number },
            setup(props) {
              expect(props.n).toBe(20)
            },
            render(this: any) {
              return h('div', this.n + ',' + typeof this.n)
            },
          })
        }),
      )
      customElements.define('my-el-async-3', E)
      container.innerHTML = `<my-el-async-3 n="2e1"></my-el-async-3>`

      await new Promise(r => setTimeout(r))

      const e = container.childNodes[0] as VueElement
      expect(e.shadowRoot!.innerHTML).toBe(`<div>20,number</div>`)
    })

    test('with slots', async () => {
      const E = defineCustomElement(
        defineAsyncComponent(() => {
          return Promise.resolve({
            render(this: any) {
              return [
                h('div', null, [
                  renderSlot(this.$slots, 'default', undefined, () => [
                    h('div', 'fallback'),
                  ]),
                ]),
                h('div', null, renderSlot(this.$slots, 'named')),
              ]
            },
          })
        }),
      )
      customElements.define('my-el-async-slots', E)
      container.innerHTML = `<my-el-async-slots><span>hi</span></my-el-async-slots>`

      await new Promise(r => setTimeout(r))

      const e = container.childNodes[0] as VueElement
      expect(e.shadowRoot!.innerHTML).toBe(
        `<div><slot><div>fallback</div></slot></div><div><slot name="named"></slot></div>`,
      )
    })
  })

  describe('shadowRoot: false', () => {
    const E = defineCustomElement({
      shadowRoot: false,
      props: {
        msg: {
          type: String,
          default: 'hello',
        },
      },
      render() {
        return h('div', this.msg)
      },
    })
    customElements.define('my-el-shadowroot-false', E)

    test('should work', async () => {
      function raf() {
        return new Promise(resolve => {
          requestAnimationFrame(resolve)
        })
      }

      container.innerHTML = `<my-el-shadowroot-false></my-el-shadowroot-false>`
      const e = container.childNodes[0] as VueElement
      await raf()
      expect(e).toBeInstanceOf(E)
      expect(e._instance).toBeTruthy()
      expect(e.innerHTML).toBe(`<div>hello</div>`)
      expect(e.shadowRoot).toBe(null)
    })

    const toggle = ref(true)
    const ES = defineCustomElement(
      {
        render() {
          return [
            renderSlot(this.$slots, 'default'),
            toggle.value ? renderSlot(this.$slots, 'named') : null,
            renderSlot(this.$slots, 'omitted', {}, () => [
              h('div', 'fallback'),
            ]),
          ]
        },
      },
      { shadowRoot: false },
    )
    customElements.define('my-el-shadowroot-false-slots', ES)

    test('should render slots', async () => {
      container.innerHTML =
        `<my-el-shadowroot-false-slots>` +
        `<span>default</span>text` +
        `<div slot="named">named</div>` +
        `</my-el-shadowroot-false-slots>`
      const e = container.childNodes[0] as VueElement
      // native slots allocation does not affect innerHTML, so we just
      // verify that we've rendered the correct native slots here...
      expect(e.innerHTML).toBe(
        `<span>default</span>text` +
          `<div slot="named">named</div>` +
          `<div>fallback</div>`,
      )

      toggle.value = false
      await nextTick()
      expect(e.innerHTML).toBe(
        `<span>default</span>text` + `<!---->` + `<div>fallback</div>`,
      )
    })

    test('render nested customElement w/ shadowRoot false', async () => {
      const calls: string[] = []

      const Child = defineCustomElement(
        {
          setup() {
            calls.push('child rendering')
            onMounted(() => {
              calls.push('child mounted')
            })
          },
          render() {
            return renderSlot(this.$slots, 'default')
          },
        },
        { shadowRoot: false },
      )
      customElements.define('my-child', Child)

      const Parent = defineCustomElement(
        {
          setup() {
            calls.push('parent rendering')
            onMounted(() => {
              calls.push('parent mounted')
            })
          },
          render() {
            return renderSlot(this.$slots, 'default')
          },
        },
        { shadowRoot: false },
      )
      customElements.define('my-parent', Parent)

      const App = {
        render() {
          return h('my-parent', null, {
            default: () => [
              h('my-child', null, {
                default: () => [h('span', null, 'default')],
              }),
            ],
          })
        },
      }
      const app = createApp(App)
      app.mount(container)
      await nextTick()
      const e = container.childNodes[0] as VueElement
      expect(e.innerHTML).toBe(
        `<my-child data-v-app=""><span>default</span></my-child>`,
      )
      expect(calls).toEqual([
        'parent rendering',
        'parent mounted',
        'child rendering',
        'child mounted',
      ])
      app.unmount()
    })

    test('render nested Teleport w/ shadowRoot false', async () => {
      const target = document.createElement('div')
      const Child = defineCustomElement(
        {
          render() {
            return h(
              Teleport,
              { to: target },
              {
                default: () => [renderSlot(this.$slots, 'default')],
              },
            )
          },
        },
        { shadowRoot: false },
      )
      customElements.define('my-el-teleport-child', Child)
      const Parent = defineCustomElement(
        {
          render() {
            return renderSlot(this.$slots, 'default')
          },
        },
        { shadowRoot: false },
      )
      customElements.define('my-el-teleport-parent', Parent)

      const App = {
        render() {
          return h('my-el-teleport-parent', null, {
            default: () => [
              h('my-el-teleport-child', null, {
                default: () => [h('span', null, 'default')],
              }),
            ],
          })
        },
      }
      const app = createApp(App)
      app.mount(container)
      await nextTick()
      expect(target.innerHTML).toBe(`<span>default</span>`)
      app.unmount()
    })

    test('render two Teleports w/ shadowRoot false', async () => {
      const target1 = document.createElement('div')
      const target2 = document.createElement('span')
      const Child = defineCustomElement(
        {
          render() {
            return [
              h(Teleport, { to: target1 }, [renderSlot(this.$slots, 'header')]),
              h(Teleport, { to: target2 }, [renderSlot(this.$slots, 'body')]),
            ]
          },
        },
        { shadowRoot: false },
      )
      customElements.define('my-el-two-teleport-child', Child)

      const App = {
        render() {
          return h('my-el-two-teleport-child', null, {
            default: () => [
              h('div', { slot: 'header' }, 'header'),
              h('span', { slot: 'body' }, 'body'),
            ],
          })
        },
      }
      const app = createApp(App)
      app.mount(container)
      await nextTick()
      expect(target1.outerHTML).toBe(
        `<div><div slot="header">header</div></div>`,
      )
      expect(target2.outerHTML).toBe(
        `<span><span slot="body">body</span></span>`,
      )
      app.unmount()
    })

    test('render two Teleports w/ shadowRoot false (with disabled)', async () => {
      const target1 = document.createElement('div')
      const target2 = document.createElement('span')
      const Child = defineCustomElement(
        {
          render() {
            return [
              // with disabled: true
              h(Teleport, { to: target1, disabled: true }, [
                renderSlot(this.$slots, 'header'),
              ]),
              h(Teleport, { to: target2 }, [renderSlot(this.$slots, 'body')]),
            ]
          },
        },
        { shadowRoot: false },
      )
      customElements.define('my-el-two-teleport-child-0', Child)

      const App = {
        render() {
          return h('my-el-two-teleport-child-0', null, {
            default: () => [
              h('div', { slot: 'header' }, 'header'),
              h('span', { slot: 'body' }, 'body'),
            ],
          })
        },
      }
      const app = createApp(App)
      app.mount(container)
      await nextTick()
      expect(target1.outerHTML).toBe(`<div></div>`)
      expect(target2.outerHTML).toBe(
        `<span><span slot="body">body</span></span>`,
      )
      app.unmount()
    })

    test('teleport target is ancestor of custom element host', async () => {
      const Child = defineCustomElement(
        {
          render() {
            return [
              h(Teleport, { to: '#t1' }, [renderSlot(this.$slots, 'header')]),
            ]
          },
        },
        { shadowRoot: false },
      )
      customElements.define('my-el-teleport-child-target', Child)

      const App = {
        render() {
          return h('div', { id: 't1' }, [
            h('my-el-teleport-child-target', null, {
              default: () => [h('div', { slot: 'header' }, 'header')],
            }),
          ])
        },
      }
      const app = createApp(App)
      app.mount(container)

      const target1 = document.getElementById('t1')!
      expect(target1.outerHTML).toBe(
        `<div id="t1">` +
          `<my-el-teleport-child-target data-v-app="">` +
          `<!--teleport start--><!--teleport end-->` +
          `</my-el-teleport-child-target>` +
          `<div slot="header">header</div>` +
          `</div>`,
      )

      app.unmount()
    })

    test('toggle nested custom element with shadowRoot: false', async () => {
      customElements.define(
        'my-el-child-shadow-false',
        defineCustomElement(
          {
            render(ctx: any) {
              return h('div', null, [renderSlot(ctx.$slots, 'default')])
            },
          },
          { shadowRoot: false },
        ),
      )
      const ChildWrapper = {
        render() {
          return h('my-el-child-shadow-false', null, 'child')
        },
      }

      customElements.define(
        'my-el-parent-shadow-false',
        defineCustomElement(
          {
            props: {
              isShown: { type: Boolean, required: true },
            },
            render(ctx: any, _: any, $props: any) {
              return $props.isShown
                ? h('div', { key: 0 }, [renderSlot(ctx.$slots, 'default')])
                : null
            },
          },
          { shadowRoot: false },
        ),
      )
      const ParentWrapper = {
        props: {
          isShown: { type: Boolean, required: true },
        },
        render(ctx: any, _: any, $props: any) {
          return h('my-el-parent-shadow-false', { isShown: $props.isShown }, [
            renderSlot(ctx.$slots, 'default'),
          ])
        },
      }

      const isShown = ref(true)
      const App = {
        render() {
          return h(ParentWrapper, { isShown: isShown.value } as any, {
            default: () => [h(ChildWrapper)],
          })
        },
      }
      const container = document.createElement('div')
      document.body.appendChild(container)
      const app = createApp(App)
      app.mount(container)
      expect(container.innerHTML).toBe(
        `<my-el-parent-shadow-false is-shown="" data-v-app="">` +
          `<div>` +
          `<my-el-child-shadow-false data-v-app="">` +
          `<div>child</div>` +
          `</my-el-child-shadow-false>` +
          `</div>` +
          `</my-el-parent-shadow-false>`,
      )

      isShown.value = false
      await nextTick()
      expect(container.innerHTML).toBe(
        `<my-el-parent-shadow-false data-v-app=""><!----></my-el-parent-shadow-false>`,
      )

      isShown.value = true
      await nextTick()
      expect(container.innerHTML).toBe(
        `<my-el-parent-shadow-false data-v-app="" is-shown="">` +
          `<div>` +
          `<my-el-child-shadow-false data-v-app="">` +
          `<div>child</div>` +
          `</my-el-child-shadow-false>` +
          `</div>` +
          `</my-el-parent-shadow-false>`,
      )
    })
  })

  describe('helpers', () => {
    test('useHost', () => {
      const Foo = defineCustomElement({
        setup() {
          const host = useHost()!
          host.setAttribute('id', 'host')
          return () => h('div', 'hello')
        },
      })
      customElements.define('my-el-use-host', Foo)
      container.innerHTML = `<my-el-use-host>`
      const el = container.childNodes[0] as VueElement
      expect(el.id).toBe('host')
    })

    test('useShadowRoot for style injection', () => {
      const Foo = defineCustomElement({
        setup() {
          const root = useShadowRoot()!
          const style = document.createElement('style')
          style.innerHTML = `div { color: red; }`
          root.appendChild(style)
          return () => h('div', 'hello')
        },
      })
      customElements.define('my-el-use-shadow-root', Foo)
      container.innerHTML = `<my-el-use-shadow-root>`
      const el = container.childNodes[0] as VueElement
      const style = el.shadowRoot?.querySelector('style')!
      expect(style.textContent).toBe(`div { color: red; }`)
    })
  })

  describe('expose', () => {
    test('expose w/ options api', async () => {
      const E = defineCustomElement({
        data() {
          return {
            value: 0,
          }
        },
        methods: {
          foo() {
            ;(this as any).value++
          },
        },
        expose: ['foo'],
        render(_ctx: any) {
          return h('div', null, _ctx.value)
        },
      })
      customElements.define('my-el-expose-options-api', E)

      container.innerHTML = `<my-el-expose-options-api></my-el-expose-options-api>`
      const e = container.childNodes[0] as VueElement & {
        foo: () => void
      }
      expect(e.shadowRoot!.innerHTML).toBe(`<div>0</div>`)
      e.foo()
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(`<div>1</div>`)
    })
    test('expose attributes and callback', async () => {
      type SetValue = (value: string) => void
      let fn: MockedFunction<SetValue>

      const E = defineCustomElement({
        setup(_, { expose }) {
          const value = ref('hello')

          const setValue = (fn = vi.fn((_value: string) => {
            value.value = _value
          }))

          expose({
            setValue,
            value,
          })

          return () => h('div', null, [value.value])
        },
      })
      customElements.define('my-el-expose', E)

      container.innerHTML = `<my-el-expose></my-el-expose>`
      const e = container.childNodes[0] as VueElement & {
        value: string
        setValue: MockedFunction<SetValue>
      }
      expect(e.shadowRoot!.innerHTML).toBe(`<div>hello</div>`)
      expect(e.value).toBe('hello')
      expect(e.setValue).toBe(fn!)
      e.setValue('world')
      expect(e.value).toBe('world')
      await nextTick()
      expect(e.shadowRoot!.innerHTML).toBe(`<div>world</div>`)
    })

    test('warning when exposing an existing property', () => {
      const E = defineCustomElement({
        props: {
          value: String,
        },
        setup(props, { expose }) {
          expose({
            value: 'hello',
          })

          return () => h('div', null, [props.value])
        },
      })
      customElements.define('my-el-expose-two', E)

      container.innerHTML = `<my-el-expose-two value="world"></my-el-expose-two>`

      expect(
        `[Vue warn]: Exposed property "value" already exists on custom element.`,
      ).toHaveBeenWarned()
    })
  })

  test('async & nested custom elements', async () => {
    let fooVal: string | undefined = ''
    const E = defineCustomElement(
      defineAsyncComponent(() => {
        return Promise.resolve({
          setup(props) {
            provide('foo', 'foo')
          },
          render(this: any) {
            return h('div', null, [renderSlot(this.$slots, 'default')])
          },
        })
      }),
    )

    const EChild = defineCustomElement({
      setup(props) {
        fooVal = inject('foo')
      },
      render(this: any) {
        return h('div', null, 'child')
      },
    })
    customElements.define('my-el-async-nested-ce', E)
    customElements.define('slotted-child', EChild)
    container.innerHTML = `<my-el-async-nested-ce><div><slotted-child></slotted-child></div></my-el-async-nested-ce>`

    await new Promise(r => setTimeout(r))
    const e = container.childNodes[0] as VueElement
    expect(e.shadowRoot!.innerHTML).toBe(`<div><slot></slot></div>`)
    expect(fooVal).toBe('foo')
  })

  test('async & multiple levels of nested custom elements', async () => {
    let fooVal: string | undefined = ''
    let barVal: string | undefined = ''
    const E = defineCustomElement(
      defineAsyncComponent(() => {
        return Promise.resolve({
          setup(props) {
            provide('foo', 'foo')
          },
          render(this: any) {
            return h('div', null, [renderSlot(this.$slots, 'default')])
          },
        })
      }),
    )

    const EChild = defineCustomElement({
      setup(props) {
        provide('bar', 'bar')
      },
      render(this: any) {
        return h('div', null, [renderSlot(this.$slots, 'default')])
      },
    })

    const EChild2 = defineCustomElement({
      setup(props) {
        fooVal = inject('foo')
        barVal = inject('bar')
      },
      render(this: any) {
        return h('div', null, 'child')
      },
    })
    customElements.define('my-el-async-nested-m-ce', E)
    customElements.define('slotted-child-m', EChild)
    customElements.define('slotted-child2-m', EChild2)
    container.innerHTML =
      `<my-el-async-nested-m-ce>` +
      `<div><slotted-child-m>` +
      `<slotted-child2-m></slotted-child2-m>` +
      `</slotted-child-m></div>` +
      `</my-el-async-nested-m-ce>`

    await new Promise(r => setTimeout(r))
    const e = container.childNodes[0] as VueElement
    expect(e.shadowRoot!.innerHTML).toBe(`<div><slot></slot></div>`)
    expect(fooVal).toBe('foo')
    expect(barVal).toBe('bar')
  })

  test('nested async custom elements should mount ancestor-first', async () => {
    const mounted: string[] = []
    const OuterComp = defineComponent({
      setup() {
        provide('foo', 'foo')
      },
      mounted() {
        mounted.push('outer')
      },
      render() {
        return h('slot')
      },
    })
    const MiddleComp = defineComponent({
      setup() {
        provide('bar', 'bar')
      },
      mounted() {
        mounted.push('middle')
      },
      render() {
        return h('slot')
      },
    })
    const InnerComp = defineComponent({
      setup() {
        const foo = inject('foo')
        const bar = inject('bar')
        return () => h('div', `${foo}/${bar}`)
      },
      mounted() {
        mounted.push('inner')
      },
    })
    let resolveOuter!: (comp: typeof OuterComp) => void
    let resolveMiddle!: (comp: typeof MiddleComp) => void
    let resolveInner!: (comp: typeof InnerComp) => void
    const outerReady = new Promise<typeof OuterComp>(resolve => {
      resolveOuter = resolve
    })
    const middleReady = new Promise<typeof MiddleComp>(resolve => {
      resolveMiddle = resolve
    })
    const innerReady = new Promise<typeof InnerComp>(resolve => {
      resolveInner = resolve
    })

    const Outer = defineCustomElement(defineAsyncComponent(() => outerReady))
    const Middle = defineCustomElement(defineAsyncComponent(() => middleReady))
    const Inner = defineCustomElement(defineAsyncComponent(() => innerReady))

    customElements.define('async-chain-outer', Outer)
    customElements.define('async-chain-middle', Middle)
    customElements.define('async-chain-inner', Inner)
    container.innerHTML =
      `<async-chain-outer>` +
      `<async-chain-middle>` +
      `<async-chain-inner></async-chain-inner>` +
      `</async-chain-middle>` +
      `</async-chain-outer>`

    resolveInner(InnerComp)
    resolveOuter(OuterComp)
    await new Promise(resolve => setTimeout(resolve))
    resolveMiddle(MiddleComp)
    await new Promise(resolve => setTimeout(resolve))

    const inner = container.querySelector('async-chain-inner') as VueElement
    expect(mounted).toEqual(['outer', 'middle', 'inner'])
    expect(inner.shadowRoot!.innerHTML).toBe('<div>foo/bar</div>')
  })

  test('should not resolve nested custom element after disconnect', async () => {
    const mounted = vi.fn()
    const ParentComp = defineComponent({
      render() {
        return h('slot')
      },
    })
    let resolveParent!: (comp: typeof ParentComp) => void
    const parentReady = new Promise<typeof ParentComp>(resolve => {
      resolveParent = resolve
    })
    const Parent = defineCustomElement(defineAsyncComponent(() => parentReady))
    const Child = defineCustomElement({
      mounted,
      render() {
        return h('div', 'child')
      },
    })

    customElements.define('async-disconnect-parent', Parent)
    customElements.define('async-disconnect-child', Child)
    container.innerHTML =
      `<async-disconnect-parent>` +
      `<async-disconnect-child></async-disconnect-child>` +
      `</async-disconnect-parent>`

    const parent = container.firstChild as VueElement
    const child = parent.firstChild as VueElement
    child.remove()
    resolveParent(ParentComp)
    await new Promise(resolve => setTimeout(resolve))

    expect(mounted).not.toHaveBeenCalled()
    expect(child.shadowRoot!.innerHTML).toBe('')

    parent.appendChild(child)
    expect(mounted).toHaveBeenCalledOnce()
    expect(child.shadowRoot!.innerHTML).toBe('<div>child</div>')
  })

  describe('configureApp', () => {
    test('should work', () => {
      const E = defineCustomElement(
        () => {
          const msg = inject('msg')
          return () => h('div', msg!)
        },
        {
          configureApp(app) {
            app.provide('msg', 'app-injected')
          },
        },
      )
      customElements.define('my-element-with-app', E)

      container.innerHTML = `<my-element-with-app></my-element-with-app>`
      const e = container.childNodes[0] as VueElement

      expect(e.shadowRoot?.innerHTML).toBe('<div>app-injected</div>')
    })

    // #12448
    test('work with async component', async () => {
      const AsyncComp = defineAsyncComponent(() => {
        return Promise.resolve({
          render() {
            const msg: string | undefined = inject('msg')
            return h('div', {}, msg)
          },
        } as any)
      })
      const E = defineCustomElement(AsyncComp, {
        configureApp(app) {
          app.provide('msg', 'app-injected')
        },
      })
      customElements.define('my-async-element-with-app', E)

      container.innerHTML = `<my-async-element-with-app></my-async-element-with-app>`
      const e = container.childNodes[0] as VueElement
      await new Promise(r => setTimeout(r))
      expect(e.shadowRoot?.innerHTML).toBe('<div>app-injected</div>')
    })

    test('with hmr reload', async () => {
      const __hmrId = '__hmrWithApp'
      const def = defineComponent({
        __hmrId,
        setup() {
          const msg = inject('msg')
          return { msg }
        },
        render(this: any) {
          return h('div', [h('span', this.msg), h('span', this.$foo)])
        },
      })
      const E = defineCustomElement(def, {
        configureApp(app) {
          app.provide('msg', 'app-injected')
          app.config.globalProperties.$foo = 'foo'
        },
      })
      customElements.define('my-element-with-app-hmr', E)

      container.innerHTML = `<my-element-with-app-hmr></my-element-with-app-hmr>`
      const el = container.childNodes[0] as VueElement
      expect(el.shadowRoot?.innerHTML).toBe(
        `<div><span>app-injected</span><span>foo</span></div>`,
      )

      // hmr
      __VUE_HMR_RUNTIME__.reload(__hmrId, def as any)

      await nextTick()
      expect(el.shadowRoot?.innerHTML).toBe(
        `<div><span>app-injected</span><span>foo</span></div>`,
      )
    })
  })

  // #9885
  test('avoid double mount when prop is set immediately after mount', () => {
    customElements.define(
      'my-input-dupe',
      defineCustomElement({
        props: {
          value: String,
        },
        render() {
          return 'hello'
        },
      }),
    )
    const container = document.createElement('div')
    document.body.appendChild(container)
    createApp({
      render() {
        return h('div', [
          h('my-input-dupe', {
            onVnodeMounted(vnode) {
              vnode.el!.value = 'fesfes'
            },
          }),
        ])
      },
    }).mount(container)
    expect(container.children[0].children[0].shadowRoot?.innerHTML).toBe(
      'hello',
    )
  })

  // #11081
  test('Props can be casted when mounting custom elements in component rendering functions', async () => {
    const E = defineCustomElement(
      defineAsyncComponent(() =>
        Promise.resolve({
          props: ['fooValue'],
          setup(props) {
            expect(props.fooValue).toBe('fooValue')
            return () => h('div', props.fooValue)
          },
        }),
      ),
    )
    customElements.define('my-el-async-4', E)
    const R = defineComponent({
      setup() {
        const fooValue = ref('fooValue')
        return () => {
          return h('div', null, [
            h('my-el-async-4', {
              fooValue: fooValue.value,
            }),
          ])
        }
      },
    })

    const app = createApp(R)
    app.mount(container)
    await new Promise(r => setTimeout(r))
    const e = container.querySelector('my-el-async-4') as VueElement
    expect(e.shadowRoot!.innerHTML).toBe(`<div>fooValue</div>`)
    app.unmount()
  })

  // #11276
  test('delete prop on attr removal', async () => {
    const E = defineCustomElement({
      props: {
        boo: {
          type: Boolean,
        },
      },
      render() {
        return this.boo + ',' + typeof this.boo
      },
    })
    customElements.define('el-attr-removal', E)
    container.innerHTML = '<el-attr-removal boo>'
    const e = container.childNodes[0] as VueElement
    expect(e.shadowRoot!.innerHTML).toBe(`true,boolean`)
    e.removeAttribute('boo')
    await nextTick()
    expect(e.shadowRoot!.innerHTML).toBe(`false,boolean`)
  })

  test('hyphenated attr removal', async () => {
    const E = defineCustomElement({
      props: {
        fooBar: {
          type: Boolean,
        },
      },
      render() {
        return this.fooBar
      },
    })
    customElements.define('el-hyphenated-attr-removal', E)
    const toggle = ref(true)
    const Comp = {
      render() {
        return h('el-hyphenated-attr-removal', {
          'foo-bar': toggle.value ? '' : null,
        })
      },
    }
    render(h(Comp), container)
    const el = container.children[0]
    expect(el.hasAttribute('foo-bar')).toBe(true)
    expect((el as any).outerHTML).toBe(
      `<el-hyphenated-attr-removal foo-bar=""></el-hyphenated-attr-removal>`,
    )

    toggle.value = false
    await nextTick()
    expect(el.hasAttribute('foo-bar')).toBe(false)
    expect((el as any).outerHTML).toBe(
      `<el-hyphenated-attr-removal></el-hyphenated-attr-removal>`,
    )
  })

  test('no unexpected mutation of the 1st argument', () => {
    const Foo = {
      name: 'Foo',
    }

    defineCustomElement(Foo, { shadowRoot: false })

    expect(Foo).toEqual({
      name: 'Foo',
    })
  })
})
