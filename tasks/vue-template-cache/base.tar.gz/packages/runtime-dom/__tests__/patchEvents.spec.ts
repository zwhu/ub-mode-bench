import { patchProp } from '../src/patchProp'

const timeout = () => new Promise(r => setTimeout(r))

describe(`runtime-dom: events patching`, () => {
  it('should assign event handler', async () => {
    const el = document.createElement('div')
    const fn = vi.fn()
    patchProp(el, 'onClick', null, fn)
    el.dispatchEvent(new Event('click'))
    await timeout()
    el.dispatchEvent(new Event('click'))
    await timeout()
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn).toHaveBeenCalledTimes(3)
  })

  it('should update event handler', async () => {
    const el = document.createElement('div')
    const prevFn = vi.fn()
    const nextFn = vi.fn()
    patchProp(el, 'onClick', null, prevFn)
    el.dispatchEvent(new Event('click'))
    patchProp(el, 'onClick', prevFn, nextFn)
    await timeout()
    el.dispatchEvent(new Event('click'))
    await timeout()
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(prevFn).toHaveBeenCalledTimes(1)
    expect(nextFn).toHaveBeenCalledTimes(2)
  })

  it('should support multiple event handlers', async () => {
    const el = document.createElement('div')
    const fn1 = vi.fn()
    const fn2 = vi.fn()
    patchProp(el, 'onClick', null, [fn1, fn2])
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn1).toHaveBeenCalledTimes(1)
    expect(fn2).toHaveBeenCalledTimes(1)
  })

  it('should snapshot event handler arrays during dispatch', async () => {
    const el = document.createElement('div')
    const fn2 = vi.fn()
    const fn3 = vi.fn()
    const fn4 = vi.fn()
    const handlers: Function[] = [
      vi.fn(() => {
        handlers[1] = fn3
        handlers.push(fn4)
      }),
      fn2,
    ]

    patchProp(el, 'onClick', null, handlers)
    el.dispatchEvent(new Event('click'))
    await timeout()

    expect(handlers[0]).toHaveBeenCalledTimes(1)
    expect(fn2).toHaveBeenCalledTimes(1)
    expect(fn3).not.toHaveBeenCalled()
    expect(fn4).not.toHaveBeenCalled()
  })

  it('should unassign event handler', async () => {
    const el = document.createElement('div')
    const fn = vi.fn()
    patchProp(el, 'onClick', null, fn)
    patchProp(el, 'onClick', fn, null)
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn).not.toHaveBeenCalled()
  })

  it('should support event option modifiers', async () => {
    const el = document.createElement('div')
    const fn = vi.fn()
    patchProp(el, 'onClickOnceCapture', null, fn)
    el.dispatchEvent(new Event('click'))
    await timeout()
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn).toHaveBeenCalledTimes(1)
  })

  it('should unassign event handler with options', async () => {
    const el = document.createElement('div')
    const fn = vi.fn()
    patchProp(el, 'onClickCapture', null, fn)
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn).toHaveBeenCalledTimes(1)

    patchProp(el, 'onClickCapture', fn, null)
    el.dispatchEvent(new Event('click'))
    await timeout()
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn).toHaveBeenCalledTimes(1)
  })

  it('should support native onclick', async () => {
    const el = document.createElement('div')

    // string should be set as attribute
    const fn = ((el as any).spy = vi.fn())
    patchProp(el, 'onclick', null, 'this.spy(1)')
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn).toHaveBeenCalledWith(1)

    const fn2 = vi.fn()
    patchProp(el, 'onclick', 'this.spy(1)', fn2)
    const event = new Event('click')
    el.dispatchEvent(event)
    await timeout()
    expect(fn).toHaveBeenCalledTimes(1)
    expect(fn2).toHaveBeenCalledWith(event)
  })

  it('should support stopImmediatePropagation on multiple listeners', async () => {
    const el = document.createElement('div')
    const fn1 = vi.fn((e: Event) => {
      e.stopImmediatePropagation()
    })
    const fn2 = vi.fn()
    patchProp(el, 'onClick', null, [fn1, fn2])
    el.dispatchEvent(new Event('click'))
    await timeout()
    expect(fn1).toHaveBeenCalledTimes(1)
    expect(fn2).toHaveBeenCalledTimes(0)
  })

  // #1747
  it('should handle same computed handler function being bound on multiple targets', async () => {
    const el1 = document.createElement('div')
    const el2 = document.createElement('div')

    // const event = new Event('click')
    const prevFn = vi.fn()
    const nextFn = vi.fn()

    patchProp(el1, 'onClick', null, prevFn)
    patchProp(el2, 'onClick', null, prevFn)

    el1.dispatchEvent(new Event('click'))
    el2.dispatchEvent(new Event('click'))
    await timeout()
    expect(prevFn).toHaveBeenCalledTimes(2)
    expect(nextFn).toHaveBeenCalledTimes(0)

    patchProp(el1, 'onClick', prevFn, nextFn)
    patchProp(el2, 'onClick', prevFn, nextFn)

    el1.dispatchEvent(new Event('click'))
    el2.dispatchEvent(new Event('click'))
    await timeout()
    expect(prevFn).toHaveBeenCalledTimes(2)
    expect(nextFn).toHaveBeenCalledTimes(2)

    el1.dispatchEvent(new Event('click'))
    el2.dispatchEvent(new Event('click'))
    await timeout()
    expect(prevFn).toHaveBeenCalledTimes(2)
    expect(nextFn).toHaveBeenCalledTimes(4)
  })

  // vuejs/vue#6566
  it('should not fire handler attached by the event itself', async () => {
    const el = document.createElement('div')
    const child = document.createElement('div')
    el.appendChild(child)
    document.body.appendChild(el)
    const childFn = vi.fn()
    const parentFn = vi.fn()

    patchProp(child, 'onClick', null, () => {
      childFn()
      patchProp(el, 'onClick', null, parentFn)
    })

    await timeout()
    child.dispatchEvent(new Event('click', { bubbles: true }))

    expect(childFn).toHaveBeenCalled()
    expect(parentFn).not.toHaveBeenCalled()
  })

  // #2841
  test('should patch event correctly in web-components', async () => {
    class TestElement extends HTMLElement {
      constructor() {
        super()
      }
    }
    window.customElements.define('test-element', TestElement)
    const testElement = document.createElement('test-element', {
      is: 'test-element',
    })
    const fn1 = vi.fn()
    const fn2 = vi.fn()

    // in webComponents, @foo-bar will patch prop 'onFooBar'
    // and @foobar will patch prop 'onFoobar'

    patchProp(testElement, 'onFooBar', null, fn1)
    testElement.dispatchEvent(new CustomEvent('foo-bar'))
    expect(fn1).toHaveBeenCalledTimes(1)

    patchProp(testElement, 'onFoobar', null, fn2)
    testElement.dispatchEvent(new CustomEvent('foobar'))
    expect(fn2).toHaveBeenCalledTimes(1)
  })

  // #8334
  test('should support once passive capture', async () => {
    const el = document.createElement('div')

    const onOnce = vi.fn()
    const onPassive = vi.fn()
    const onCapture = vi.fn()

    patchProp(el, 'onOnce', null, onOnce)
    patchProp(el, 'onPassive', null, onPassive)
    patchProp(el, 'onCapture', null, onCapture)

    el.dispatchEvent(new Event('once'))
    await timeout()
    expect(onOnce).toHaveBeenCalledTimes(1)

    el.dispatchEvent(new Event('passive'))
    await timeout()
    expect(onPassive).toHaveBeenCalledTimes(1)

    el.dispatchEvent(new Event('capture'))
    await timeout()
    expect(onCapture).toHaveBeenCalledTimes(1)
  })

  test('should support once passive capture in web-components', async () => {
    class TestCustomElement extends HTMLElement {
      constructor() {
        super()
      }
    }

    if (!window.customElements.get('hello-world')) {
      window.customElements.define('hello-world', TestCustomElement)
    }

    const customElement = document.createElement('hello-world')

    const onOnce = vi.fn()
    const onPassive = vi.fn()
    const onCapture = vi.fn()

    patchProp(customElement, 'onOnce', null, onOnce)
    patchProp(customElement, 'onPassive', null, onPassive)
    patchProp(customElement, 'onCapture', null, onCapture)

    customElement.dispatchEvent(new CustomEvent('once'))
    expect(onOnce).toHaveBeenCalledTimes(1)

    customElement.dispatchEvent(new CustomEvent('passive'))
    expect(onPassive).toHaveBeenCalledTimes(1)

    customElement.dispatchEvent(new CustomEvent('capture'))
    expect(onCapture).toHaveBeenCalledTimes(1)
  })

  test('should support once event with the once modifier', async () => {
    const el = document.createElement('div')

    const onOnce = vi.fn()

    patchProp(el, 'onOnceOnce', null, onOnce)

    el.dispatchEvent(new Event('once'))
    await timeout()
    expect(onOnce).toHaveBeenCalledTimes(1)

    el.dispatchEvent(new Event('once'))
    await timeout()
    expect(onOnce).toHaveBeenCalledTimes(1)
  })

  test('should support preserved-case option modifier event names', async () => {
    const el = document.createElement('div')

    const onOnce = vi.fn()
    const onPassive = vi.fn()
    const onCapture = vi.fn()

    patchProp(el, 'on:Once', null, onOnce)
    patchProp(el, 'on:Passive', null, onPassive)
    patchProp(el, 'on:Capture', null, onCapture)

    el.dispatchEvent(new Event('Once'))
    await timeout()
    expect(onOnce).toHaveBeenCalledTimes(1)

    el.dispatchEvent(new Event('Passive'))
    await timeout()
    expect(onPassive).toHaveBeenCalledTimes(1)

    el.dispatchEvent(new Event('Capture'))
    await timeout()
    expect(onCapture).toHaveBeenCalledTimes(1)
  })

  it('handles an unknown type', () => {
    const el = document.createElement('div')
    patchProp(el, 'onClick', null, 'test')
    el.dispatchEvent(new Event('click'))
    expect(
      `Wrong type passed as event handler to onClick - did you forget @ or : ` +
        `in front of your prop?\nExpected function or array of functions, received type string.`,
    ).toHaveBeenWarned()
  })
})
